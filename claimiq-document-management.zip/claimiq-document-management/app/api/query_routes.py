from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.query_schema import PolicyQueryRequest, PolicyQueryResponse
from app.services.rag_service import RagService

router = APIRouter(prefix="/api/v1/ai", tags=["AI Query"])


@router.post("/query", response_model=PolicyQueryResponse)
def query_policy(request: PolicyQueryRequest, db: Session = Depends(get_db)):
    try:
        return RagService().answer(request.question, db, request.policy_code, request.user_id)
    except Exception as exc:
        raise HTTPException(500, f"Query failed: {exc}")
