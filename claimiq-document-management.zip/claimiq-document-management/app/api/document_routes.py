import hashlib, uuid
from datetime import date
from pathlib import Path
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.document import Document, DocumentStatus
from app.services.audit_service import add_audit
from app.services.blob_service import BlobStorageService
from app.services.ingestion_service import IngestionService

router = APIRouter(prefix="/api/v1/documents", tags=["Documents"])
ALLOWED_EXTENSIONS = {".pdf", ".docx"}
MAX_FILE_SIZE = 10 * 1024 * 1024


@router.post("")
async def upload_document(
    policy_code: str = Form(...),
    document_name: str = Form(...),
    version: str = Form(...),
    effective_from: date = Form(...),
    uploaded_by: str = Form(...),
    replaces_document_id: str | None = Form(None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    extension = Path(file.filename or "").suffix.lower()
    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, "Only PDF and DOCX files are supported")
    content = await file.read()
    if not content:
        raise HTTPException(400, "Uploaded file is empty")
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(400, "File exceeds 10 MB")
    if replaces_document_id and not db.get(Document, replaces_document_id):
        raise HTTPException(404, "Document to replace was not found")

    document_id = str(uuid.uuid4())
    safe_name = Path(file.filename or "document").name
    blob_path = f"policies/{policy_code}/{version}/{document_id}/{safe_name}"
    BlobStorageService().upload_bytes(blob_path, content, file.content_type or "application/octet-stream")

    document = Document(
        id=document_id,
        policy_code=policy_code,
        document_name=document_name,
        original_file_name=safe_name,
        blob_path=blob_path,
        file_type=extension,
        file_size=len(content),
        version=version,
        status=DocumentStatus.UPLOADED,
        is_active=False,
        effective_from=effective_from,
        checksum=hashlib.sha256(content).hexdigest(),
        uploaded_by=uploaded_by,
        supersedes_document_id=replaces_document_id,
    )
    try:
        db.add(document)
        add_audit(db, "DOCUMENT_UPLOADED", document.id, uploaded_by, {"version": version})
        db.commit()
        db.refresh(document)
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "This policy version already exists")
    return {"document_id": document.id, "status": document.status.value, "blob_path": document.blob_path}


@router.post("/{document_id}/process")
def process_document(document_id: str, db: Session = Depends(get_db)):
    try:
        document = IngestionService().process(document_id, db)
        return {"document_id": document.id, "status": document.status.value, "is_active": document.is_active}
    except ValueError as exc:
        raise HTTPException(404, str(exc))
    except Exception as exc:
        raise HTTPException(500, f"Processing failed: {exc}")


@router.get("/{document_id}")
def get_document(document_id: str, db: Session = Depends(get_db)):
    document = db.get(Document, document_id)
    if not document:
        raise HTTPException(404, "Document not found")
    return {
        "id": document.id,
        "policy_code": document.policy_code,
        "document_name": document.document_name,
        "version": document.version,
        "status": document.status.value,
        "is_active": document.is_active,
        "processing_error": document.processing_error,
    }
