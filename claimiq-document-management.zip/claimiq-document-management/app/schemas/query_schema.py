from pydantic import BaseModel, Field


class PolicyQueryRequest(BaseModel):
    question: str = Field(min_length=3, max_length=2000)
    policy_code: str | None = None
    user_id: str | None = None


class SourceReference(BaseModel):
    document_id: str
    document_name: str
    version: str
    page_number: int | None = None
    chunk_id: str


class PolicyQueryResponse(BaseModel):
    answer: str
    sources: list[SourceReference]
    response_time_ms: int
