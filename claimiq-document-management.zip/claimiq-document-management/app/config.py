from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    app_name: str = "ClaimIQ Document Management"
    app_env: str = "development"
    database_url: str = "sqlite:///./claimiq.db"

    azure_storage_account_name: str = ""
    azure_storage_container: str = "policy-documents"
    azure_storage_connection_string: str = ""

    azure_search_endpoint: str = ""
    azure_search_index_name: str = "policy-chunks"
    azure_search_api_key: str = ""

    azure_openai_endpoint: str = ""
    azure_openai_embedding_deployment: str = ""
    azure_openai_chat_deployment: str = ""
    azure_openai_api_key: str = ""

    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


settings = Settings()
