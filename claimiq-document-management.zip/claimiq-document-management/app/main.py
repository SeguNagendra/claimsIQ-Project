from fastapi import FastAPI
from app import models  # noqa: F401
from app.api.document_routes import router as document_router
from app.api.query_routes import router as query_router
from app.config import settings
from app.database import Base, engine

Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, version="1.0.0")
app.include_router(document_router)
app.include_router(query_router)


@app.get("/health")
def health_check():
    return {"status": "healthy", "application": settings.app_name, "environment": settings.app_env}
