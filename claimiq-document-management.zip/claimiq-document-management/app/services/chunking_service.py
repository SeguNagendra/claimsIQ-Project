class ChunkingService:
    def __init__(self, chunk_size: int = 1200, chunk_overlap: int = 200):
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def chunk_pages(self, pages: list[dict]) -> list[dict]:
        chunks, number = [], 0
        for page in pages:
            text = " ".join(page["text"].split())
            start = 0
            while start < len(text):
                end = min(start + self.chunk_size, len(text))
                chunk_text = text[start:end].strip()
                if chunk_text:
                    chunks.append({"chunk_number": number, "page_number": page["page_number"], "chunk_text": chunk_text})
                    number += 1
                if end >= len(text):
                    break
                start = end - self.chunk_overlap
        return chunks
