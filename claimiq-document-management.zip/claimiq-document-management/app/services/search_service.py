from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from app.config import settings
from app.services.azure_auth import get_search_credential


class SearchService:
    def __init__(self):
        if not settings.azure_search_endpoint:
            raise ValueError("AZURE_SEARCH_ENDPOINT is missing from .env")
        self.client = SearchClient(
            endpoint=settings.azure_search_endpoint,
            index_name=settings.azure_search_index_name,
            credential=get_search_credential(),
        )

    def upload_chunks(self, chunks: list[dict]):
        results = self.client.upload_documents(documents=chunks)
        failed = [x for x in results if not x.succeeded]
        if failed:
            raise RuntimeError(f"{len(failed)} search records failed to index")

    def deactivate_chunks(self, chunk_ids: list[str]):
        if not chunk_ids:
            return
        results = self.client.merge_documents(documents=[{"id": x, "is_active": False} for x in chunk_ids])
        failed = [x for x in results if not x.succeeded]
        if failed:
            raise RuntimeError(f"{len(failed)} search records failed to deactivate")

    def search(self, question_vector: list[float], policy_code: str | None = None, top_k: int = 5) -> list[dict]:
        filters = ["is_active eq true"]
        if policy_code:
            filters.append(f"policy_code eq '{policy_code.replace(chr(39), chr(39) * 2)}'")
        query = VectorizedQuery(vector=question_vector, k_nearest_neighbors=top_k, fields="content_vector")
        results = self.client.search(
            search_text=None,
            vector_queries=[query],
            filter=" and ".join(filters),
            select=["id", "document_id", "policy_code", "document_name", "version", "chunk_text", "page_number"],
            top=top_k,
        )
        return [dict(x) for x in results]
