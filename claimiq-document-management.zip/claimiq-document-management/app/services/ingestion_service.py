from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models.document import Document, DocumentStatus
from app.models.document_chunk import DocumentChunk
from app.services.audit_service import add_audit
from app.services.blob_service import BlobStorageService
from app.services.chunking_service import ChunkingService
from app.services.embedding_service import EmbeddingService
from app.services.extraction_service import TextExtractionService
from app.services.search_service import SearchService


class IngestionService:
    def process(self, document_id: str, db: Session) -> Document:
        document = db.get(Document, document_id)
        if not document:
            raise ValueError("Document not found")
        if document.status == DocumentStatus.ACTIVE:
            return document

        document.status = DocumentStatus.PROCESSING
        document.processing_error = None
        add_audit(db, "DOCUMENT_PROCESSING_STARTED", document.id, document.uploaded_by)
        db.commit()

        created_ids = []
        try:
            content = BlobStorageService().download_bytes(document.blob_path)
            pages = TextExtractionService().extract(content, document.file_type)
            if not pages:
                raise ValueError("No text could be extracted. Scanned PDFs require OCR.")
            raw_chunks = ChunkingService().chunk_pages(pages)
            if not raw_chunks:
                raise ValueError("No valid chunks were created")

            embedding_service = EmbeddingService()
            search_records = []
            for item in raw_chunks:
                row = DocumentChunk(
                    document_id=document.id,
                    chunk_number=item["chunk_number"],
                    chunk_text=item["chunk_text"],
                    page_number=item["page_number"],
                    is_active=True,
                )
                db.add(row)
                db.flush()
                created_ids.append(row.id)
                search_records.append({
                    "id": row.id,
                    "document_id": document.id,
                    "policy_code": document.policy_code,
                    "document_name": document.document_name,
                    "version": document.version,
                    "chunk_number": row.chunk_number,
                    "chunk_text": row.chunk_text,
                    "page_number": row.page_number,
                    "is_active": True,
                    "content_vector": embedding_service.generate_embedding(row.chunk_text),
                })

            search_service = SearchService()
            search_service.upload_chunks(search_records)

            if document.supersedes_document_id:
                old = db.get(Document, document.supersedes_document_id)
                if old:
                    old_chunks = db.query(DocumentChunk).filter(DocumentChunk.document_id == old.id).all()
                    old_ids = [x.id for x in old_chunks]
                    search_service.deactivate_chunks(old_ids)
                    for chunk in old_chunks:
                        chunk.is_active = False
                    old.status = DocumentStatus.SUPERSEDED
                    old.is_active = False
                    old.effective_to = document.effective_from
                    add_audit(db, "DOCUMENT_SUPERSEDED", old.id, document.uploaded_by, {"replacement_id": document.id})

            document.status = DocumentStatus.ACTIVE
            document.is_active = True
            document.processed_at = datetime.now(timezone.utc)
            add_audit(db, "DOCUMENT_ACTIVATED", document.id, document.uploaded_by, {"chunks": len(search_records)})
            db.commit()
            db.refresh(document)
            return document
        except Exception as exc:
            db.rollback()
            document = db.get(Document, document_id)
            document.status = DocumentStatus.FAILED
            document.is_active = False
            document.processing_error = str(exc)[:4000]
            add_audit(db, "DOCUMENT_PROCESSING_FAILED", document.id, document.uploaded_by, {"error": str(exc)[:1000]})
            db.commit()
            raise
