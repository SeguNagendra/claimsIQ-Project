from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient, ContentSettings
from app.config import settings


class BlobStorageService:
    def __init__(self):
        if settings.azure_storage_connection_string:
            self.client = BlobServiceClient.from_connection_string(settings.azure_storage_connection_string)
        else:
            if not settings.azure_storage_account_name:
                raise ValueError("AZURE_STORAGE_ACCOUNT_NAME is missing from .env")
            account_url = f"https://{settings.azure_storage_account_name}.blob.core.windows.net"
            self.client = BlobServiceClient(account_url, credential=DefaultAzureCredential())
        self.container_client = self.client.get_container_client(settings.azure_storage_container)

    def upload_bytes(self, blob_path: str, content: bytes, content_type: str) -> str:
        blob = self.container_client.get_blob_client(blob_path)
        blob.upload_blob(content, overwrite=False, content_settings=ContentSettings(content_type=content_type))
        return blob.url

    def download_bytes(self, blob_path: str) -> bytes:
        return self.container_client.get_blob_client(blob_path).download_blob().readall()
