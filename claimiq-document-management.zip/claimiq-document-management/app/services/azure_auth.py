from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai import OpenAI
from app.config import settings


def get_openai_client() -> OpenAI:
    endpoint = settings.azure_openai_endpoint.rstrip("/") + "/"
    if not endpoint or endpoint == "/":
        raise ValueError("AZURE_OPENAI_ENDPOINT is missing from .env")
    if settings.azure_openai_api_key:
        return OpenAI(base_url=endpoint, api_key=settings.azure_openai_api_key)
    provider = get_bearer_token_provider(DefaultAzureCredential(), "https://ai.azure.com/.default")
    return OpenAI(base_url=endpoint, api_key=provider)


def get_search_credential():
    if settings.azure_search_api_key:
        return AzureKeyCredential(settings.azure_search_api_key)
    return DefaultAzureCredential()
