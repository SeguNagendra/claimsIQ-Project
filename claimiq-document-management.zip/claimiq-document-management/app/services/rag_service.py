import time
from sqlalchemy.orm import Session
from app.config import settings
from app.models.query_log import QueryLog
from app.prompts.rag_prompt import SYSTEM_PROMPT
from app.services.azure_auth import get_openai_client
from app.services.embedding_service import EmbeddingService
from app.services.search_service import SearchService

NO_MATCH = "I could not find relevant information in the currently approved policy documents."


class RagService:
    def answer(self, question: str, db: Session, policy_code: str | None = None, user_id: str | None = None) -> dict:
        started = time.perf_counter()
        vector = EmbeddingService().generate_embedding(question)
        matches = SearchService().search(vector, policy_code=policy_code, top_k=5)

        if not matches:
            answer, sources, status = NO_MATCH, [], "NO_MATCH"
        else:
            context = "\n\n---\n\n".join(
                f"Document: {m['document_name']}\nVersion: {m['version']}\nPage: {m.get('page_number')}\nContent: {m['chunk_text']}"
                for m in matches
            )
            if not settings.azure_openai_chat_deployment:
                raise ValueError("AZURE_OPENAI_CHAT_DEPLOYMENT is missing from .env")
            response = get_openai_client().responses.create(
                model=settings.azure_openai_chat_deployment,
                instructions=SYSTEM_PROMPT,
                input=f"POLICY CONTEXT:\n{context}\n\nUSER QUESTION:\n{question}",
            )
            answer = response.output_text.strip()
            sources = [
                {
                    "document_id": m["document_id"],
                    "document_name": m["document_name"],
                    "version": m["version"],
                    "page_number": m.get("page_number"),
                    "chunk_id": m["id"],
                }
                for m in matches
            ]
            status = "ANSWERED"

        elapsed = int((time.perf_counter() - started) * 1000)
        log = QueryLog(user_id=user_id, question=question, answer=answer, response_time_ms=elapsed, status=status)
        log.set_sources(sources)
        db.add(log)
        db.commit()
        return {"answer": answer, "sources": sources, "response_time_ms": elapsed}
