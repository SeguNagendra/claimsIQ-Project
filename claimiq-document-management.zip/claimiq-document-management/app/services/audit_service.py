from app.models.audit_log import AuditLog


def add_audit(db, action: str, entity_id: str, user_id: str | None = None, details: dict | None = None):
    event = AuditLog(user_id=user_id, action=action, entity_type="DOCUMENT", entity_id=entity_id)
    event.set_details(details or {})
    db.add(event)
