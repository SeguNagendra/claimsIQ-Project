from app.config import settings
from app.services.azure_auth import get_openai_client


class EmbeddingService:
    def __init__(self):
        if not settings.azure_openai_embedding_deployment:
            raise ValueError("AZURE_OPENAI_EMBEDDING_DEPLOYMENT is missing from .env")
        self.client = get_openai_client()

    def generate_embedding(self, text: str) -> list[float]:
        response = self.client.embeddings.create(
            model=settings.azure_openai_embedding_deployment,
            input=text,
        )
        return response.data[0].embedding
