from io import BytesIO
import fitz
from docx import Document as WordDocument


class TextExtractionService:
    def extract_pdf(self, content: bytes) -> list[dict]:
        pdf = fitz.open(stream=content, filetype="pdf")
        try:
            return [
                {"page_number": i + 1, "text": page.get_text("text").strip()}
                for i, page in enumerate(pdf)
                if page.get_text("text").strip()
            ]
        finally:
            pdf.close()

    def extract_docx(self, content: bytes) -> list[dict]:
        document = WordDocument(BytesIO(content))
        paragraphs = [p.text.strip() for p in document.paragraphs if p.text.strip()]
        text = "\n".join(paragraphs)
        return [{"page_number": None, "text": text}] if text else []

    def extract(self, content: bytes, file_type: str) -> list[dict]:
        if file_type == ".pdf":
            return self.extract_pdf(content)
        if file_type == ".docx":
            return self.extract_docx(content)
        raise ValueError(f"Unsupported file type: {file_type}")
