import enum
import uuid
from sqlalchemy import Boolean, Column, Date, DateTime, Enum, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.sql import func
from app.database import Base


class DocumentStatus(str, enum.Enum):
    UPLOADED = "UPLOADED"
    PROCESSING = "PROCESSING"
    ACTIVE = "ACTIVE"
    FAILED = "FAILED"
    SUPERSEDED = "SUPERSEDED"
    DEACTIVATED = "DEACTIVATED"


class Document(Base):
    __tablename__ = "documents"
    __table_args__ = (UniqueConstraint("policy_code", "version", name="uq_policy_version"),)

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    policy_code = Column(String(100), nullable=False, index=True)
    document_name = Column(String(255), nullable=False)
    original_file_name = Column(String(255), nullable=False)
    blob_path = Column(String(1000), nullable=False, unique=True)
    file_type = Column(String(20), nullable=False)
    file_size = Column(Integer, nullable=False)
    version = Column(String(50), nullable=False)
    status = Column(Enum(DocumentStatus), nullable=False, default=DocumentStatus.UPLOADED)
    is_active = Column(Boolean, nullable=False, default=False)
    effective_from = Column(Date, nullable=True)
    effective_to = Column(Date, nullable=True)
    checksum = Column(String(64), nullable=False)
    uploaded_by = Column(String(255), nullable=False)
    supersedes_document_id = Column(String, ForeignKey("documents.id"), nullable=True)
    processing_error = Column(Text, nullable=True)
    uploaded_at = Column(DateTime(timezone=True), server_default=func.now())
    processed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
