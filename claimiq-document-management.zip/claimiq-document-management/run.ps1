$ErrorActionPreference = "Stop"
if (-not (Test-Path ".venv")) { python -m venv .venv }
& .\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env" }
Write-Host "Edit .env with your Azure details, then run: az login"
Write-Host "Starting API at http://127.0.0.1:8000/docs"
python -m uvicorn app.main:app --reload
