from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    HnswAlgorithmConfiguration,
    SearchField,
    SearchFieldDataType,
    SearchIndex,
    SearchableField,
    SimpleField,
    VectorSearch,
    VectorSearchProfile,
)
from app.config import settings
from app.services.azure_auth import get_search_credential
from app.services.embedding_service import EmbeddingService


def main():
    dimension = len(EmbeddingService().generate_embedding("dimension test"))
    fields = [
        SimpleField(name="id", type=SearchFieldDataType.String, key=True, filterable=True),
        SimpleField(name="document_id", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="policy_code", type=SearchFieldDataType.String, filterable=True),
        SearchableField(name="document_name", type=SearchFieldDataType.String),
        SimpleField(name="version", type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="chunk_number", type=SearchFieldDataType.Int32, sortable=True),
        SearchableField(name="chunk_text", type=SearchFieldDataType.String),
        SimpleField(name="page_number", type=SearchFieldDataType.Int32, filterable=True),
        SimpleField(name="is_active", type=SearchFieldDataType.Boolean, filterable=True),
        SearchField(
            name="content_vector",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=dimension,
            vector_search_profile_name="claimiq-vector-profile",
        ),
    ]
    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="claimiq-hnsw")],
        profiles=[VectorSearchProfile(name="claimiq-vector-profile", algorithm_configuration_name="claimiq-hnsw")],
    )
    index = SearchIndex(name=settings.azure_search_index_name, fields=fields, vector_search=vector_search)
    client = SearchIndexClient(settings.azure_search_endpoint, get_search_credential())
    client.create_or_update_index(index)
    print(f"Search index '{settings.azure_search_index_name}' is ready. Vector dimension: {dimension}")


if __name__ == "__main__":
    main()
