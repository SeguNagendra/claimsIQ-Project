from app.config import settings
from app.services.azure_auth import get_openai_client

response = get_openai_client().responses.create(
    model=settings.azure_openai_chat_deployment,
    instructions="Answer only from the supplied policy context.",
    input="Policy context: Emergency towing is covered. Question: Is emergency towing covered?",
)
print(response.output_text)
