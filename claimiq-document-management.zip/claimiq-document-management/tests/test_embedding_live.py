from app.config import settings
from app.services.embedding_service import EmbeddingService

print("Endpoint:", settings.azure_openai_endpoint)
print("Embedding deployment:", settings.azure_openai_embedding_deployment)
vector = EmbeddingService().generate_embedding("Emergency towing is covered by the motor policy.")
print("Embedding created successfully")
print("Dimension:", len(vector))
print("First five values:", vector[:5])
