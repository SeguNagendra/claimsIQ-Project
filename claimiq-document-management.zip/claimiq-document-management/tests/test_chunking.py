from app.services.chunking_service import ChunkingService


def test_chunking_creates_overlap():
    service = ChunkingService(chunk_size=20, chunk_overlap=5)
    chunks = service.chunk_pages([{"page_number": 1, "text": "abcdefghijklmnopqrstuvwxyz"}])
    assert len(chunks) == 2
    assert chunks[0]["page_number"] == 1
    assert chunks[1]["chunk_text"].startswith("pqrst")
