# ClaimIQ Document Management and RAG

A beginner-friendly FastAPI project for:

- uploading PDF/DOCX policy documents to Azure Blob Storage;
- extracting and chunking document text;
- generating Azure OpenAI embeddings;
- indexing active policy chunks in Azure AI Search;
- answering policy questions with retrieved context and citations;
- superseding older policy versions only after the new version is indexed.

## 1. Prerequisites

- Python 3.11 or 3.12
- Azure CLI
- An Azure Storage account and private container named `policy-documents`
- Azure AI Search with permission to manage indexes and documents
- Azure OpenAI with embedding and chat deployments

For Microsoft Entra ID authentication, the signed-in user needs suitable data-plane roles on all three resources. For Azure OpenAI invocation, use `Cognitive Services OpenAI User` on the Azure OpenAI resource.

## 2. Open in VS Code

Extract the ZIP and open the extracted folder in VS Code.

In PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\run.ps1
```

The script creates a virtual environment, installs dependencies, copies `.env.example` to `.env` if required, and starts the API. Stop it, edit `.env`, run `az login`, and start it again if the Azure values were not set yet.

Manual commands:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
az login
python -m uvicorn app.main:app --reload
```

## 3. Configure `.env`

```dotenv
DATABASE_URL=sqlite:///./claimiq.db
AZURE_STORAGE_ACCOUNT_NAME=your-storage-account-name
AZURE_STORAGE_CONTAINER=policy-documents
AZURE_SEARCH_ENDPOINT=https://your-search-service.search.windows.net
AZURE_SEARCH_INDEX_NAME=policy-chunks
AZURE_OPENAI_ENDPOINT=https://your-openai-resource.openai.azure.com/openai/v1/
AZURE_OPENAI_EMBEDDING_DEPLOYMENT=your-exact-embedding-deployment-name
AZURE_OPENAI_CHAT_DEPLOYMENT=your-exact-chat-deployment-name
```

The URL is the value of `AZURE_OPENAI_ENDPOINT`. Never put the URL inside `os.environ[...]`.

## 4. Verify Azure OpenAI first

```powershell
python tests\test_embedding_live.py
python tests\test_chat_live.py
```

If Azure returns `PermissionDenied` for the embeddings action, assign `Cognitive Services OpenAI User` to the identity shown in the error on the correct Azure OpenAI resource. After assignment, run `az logout`, `az login`, and retry.

## 5. Create the Azure AI Search index

```powershell
python scripts\create_search_index.py
```

The script calls the embedding deployment once to discover the vector dimension and creates or updates the `policy-chunks` index.

## 6. Start and use the API

```powershell
python -m uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`.

Recommended order:

1. `GET /health`
2. `POST /api/v1/documents`
3. `POST /api/v1/documents/{document_id}/process`
4. `GET /api/v1/documents/{document_id}`
5. `POST /api/v1/ai/query`

The upload API requires these multipart fields: `policy_code`, `document_name`, `version`, `effective_from`, `uploaded_by`, optional `replaces_document_id`, and `file`.

## Important MVP notes

- SQLite is used so the project runs immediately. Replace it with PostgreSQL through `DATABASE_URL` for a team deployment.
- Authentication/RBAC enforcement at the FastAPI route layer is not included. Add your organisation's identity integration before production use.
- Scanned PDFs require OCR and are rejected if no text can be extracted.
- Old documents are marked `SUPERSEDED`; their search records are updated to `is_active=false`.
- The `/process` route runs synchronously for clarity. Use a queue/worker for production.
- Use fictional policies only while testing.
